const mongoose = require("mongoose");
const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const studentObj = {
    firstname: String,
    lastname: String,
    email: String,
    gender: String,
    phone: Number,
    age: Number,
    password: String,
    verified: Boolean,
    type: String,
    jti: String
}
const studentSchema = mongoose.Schema(studentObj);

studentSchema.methods.generateToken = async function () {
    try {

        // console.log(this._id);
        const randomStr = Math.random().toString(36);

        const token = jwt.sign({
            _id: this._id.toString(),
            jti: randomStr
        }, process.env.SECRETKEY);


        this.jti = randomStr;
        await this.save();
        // console.log(token,'tokeeeen');
        return token;
    } catch (err) {
        return err;
    }
}

const student = mongoose.model("studentCol", studentSchema);
module.exports = student;
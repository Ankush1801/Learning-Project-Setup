const mongoose = require("mongoose");
const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const userObj = {
    phone: String,
    otpString: String,
    createdAt: { type: Date, default: Date.now, index: { expires: 300 } }
}
const OtpSchema = mongoose.Schema(userObj, { timestamps: true });
const otp = mongoose.model("otpCol", OtpSchema);
module.exports = otp;


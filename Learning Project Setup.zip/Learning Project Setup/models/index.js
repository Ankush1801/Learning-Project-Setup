module.exports = {
    admin: require("./admin_teacher"),
    otp: require("./otp"),
    student: require("./student")
}
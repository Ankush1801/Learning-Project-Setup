const model = require("../models/index");
const bcrypt = require("bcrypt");
const otpGenetaror = require("otp-generator");
const mongoose = require("mongoose");
const express = require("express");
const jwt = require("jsonwebtoken");


async function sendOtp(req, res) {

    const student = await model.student.findOne({ phone: req.body.phone });
    if (student)
        return res.status(400).send("Student already exists");
    const OTP = otpGenetaror.generate(6, { digits: true, lowerCaseAlphabets: false, upperCaseAlphabets: false, specialChars: false });

    const number = req.body.phone;
    const otp = new model.otp({
        phone: number,
        otpString: OTP
    });
    const result = await otp.save();
    return "OTP sent sucessfully";
}


async function verifyOtp(req, res) {

    const otpHolder = await model.otp.find({ phone: req.body.phone });
    console.log(otpHolder);
    if (otpHolder.length === 0) {
        console.log('Length       ', otpHolder.length);
        return ("OTP is expiredddddddddddd");
    }
    const rightOtpFind = otpHolder[otpHolder.length - 1];


    if ((req.body.phone === rightOtpFind.phone) && (req.body.otp === rightOtpFind.otpString)) {

        const student = new model.student({ phone: req.body.phone });

        const check = await model.student.findOne({ phone: req.body.phone })
        if (check) {
            return ("Student allready exists");
        }
        else {
            const token = await student.generateToken();

            const registeredStudent = await student.save();
            return ({ "Token": token });
        }
    }
    else {
        return ("Invalid OTP");
    }

}

async function verifyToken(req, res, next) {
    let token = req.headers['x-acceess-token'] || req.headers['authorization'];
    if (token == undefined) {
        return ({ "error": "Token not found" });
    }
    if (token.startsWith('Bearer')) {
        token = token.slice(7, token.length);
    }
    const uu = await jwt.verify(token, process.env.SECRETKEY);
    if (uu) {
        req.body.student = uu;
        next();
    }

}

async function profileSetup(req, res) {


    const student = await model.student.findOneAndUpdate({ "_id": req.body.student._id }, {
        $set: {
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            gender: req.body.gender,
            age: req.body.age,
            type: req.body.type,
            password: await bcrypt.hash(req.body.password, 10)
        }
    }, { new: true });

    return student;
}
async function login(req, res) {
    console.log(req.body.password);
    const student = await model.student.findOne({ phone: req.body.phone });
    // console.log(admin, " lllllllllllllllllllll")
    if (!student) {
        return ("User not found");
    }
    else {
        let check = false;
        check = await bcrypt.compareSync(req.body.password, student.password);
        console.log(check);
        //  check = true;
        if (check) {

            const token = await student.generateToken();

            console.log({ "Token :: ": token })
            return { "Token :: ": token };

        }
        else {
            return ("Incorrect Password");
        }

    }
}





module.exports = {
    sendOtp,
    verifyOtp,
    profileSetup,
    login,
    verifyToken
}
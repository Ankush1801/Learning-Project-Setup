const model = require("../models/index");
const bcrypt = require("bcrypt");
const otpGenetaror = require("otp-generator");
const mongoose = require("mongoose");
const express = require("express");
const jwt = require("jsonwebtoken");


async function sendOtp(req, res) {
    const admin = await model.admin.findOne({ phone: req.body.phone });
    if (admin)
        return res.status(400).send("Admin already exists");
    const OTP = otpGenetaror.generate(6, { digits: true, lowerCaseAlphabets: false, upperCaseAlphabets: false, specialChars: false });

    const number = req.body.phone;
    const otp = new model.otp({
        phone: number,
        otpString: OTP
    });
    const result = await otp.save();
    return "OTP sent sucessfully";
}


async function verifyOtp(req, res) {

    const otpHolder = await model.otp.find({ phone: req.body.phone });
    console.log(otpHolder);
    if (otpHolder.length === 0) {
        console.log('Length       ', otpHolder.length);
        return ("OTP is expiredddddddddddd");
    }
    const rightOtpFind = otpHolder[otpHolder.length - 1];


    if ((req.body.phone === rightOtpFind.phone) && (req.body.otp === rightOtpFind.otpString)) {

        const admin = new model.admin({ phone: req.body.phone });

        const check = await model.admin.findOne({ phone: req.body.phone })
        if (check) {
            return ("User allready exists");
        }
        else {
            const token = await admin.generateToken();

            const registeredUser = await admin.save();
            return ({ "Token": token });
        }
    }
    else {
        return ("Invalid OTP");
    }

}
async function verifyOtpForForgotPassword(req, res) {

    const otpHolder = await model.otp.find({ phone: req.body.phone });
    console.log(otpHolder);
    if (otpHolder.length === 0) {
        console.log('Length       ', otpHolder.length);
        return ("OTP is expiredddddddddddd");
    }
    const rightOtpFind = otpHolder[otpHolder.length - 1];


    if ((req.body.phone === rightOtpFind.phone) && (req.body.otp === rightOtpFind.otpString)) {


        const admin = await model.admin.findOne({ phone: req.body.phone })


        const token = await admin.getenerateTokenForForgotPassword();

        const registeredUser = await admin.save();
        return ({ "Token": token });

    }
    else {
        return ("Invalid OTP");
    }

}
async function verifyToken(req, res, next) {
    let token = req.headers['x-acceess-token'] || req.headers['authorization'];
    if (token == undefined) {
        return ({ "error": "Token not found" });
    }
    if (token.startsWith('Bearer')) {
        token = token.slice(7, token.length);
    }
    const uu = await jwt.verify(token, process.env.SECRETKEY);
    if (uu) {
        req.body.admin = uu;
        next();
    }

}

async function verifyAdmin(req, res, next) {

    let token1 = req.headers['x-acceess-token'] || req.headers['authorization'];

    if (token1 == undefined) {
        return ({ "error": "Token not found" });
    }
    if (token1.startsWith('Bearer')) {
        token1 = token1.slice(7, token1.length);
    }

    const uu = await jwt.verify(token1, process.env.SECRETKEY);

    req.body.admin = uu;


    const u1 = await model.admin.findOne({ "_id": req.body.admin._id });
    if (!u1) {
        return "User not found"
    }
    if (u1.jti === req.body.admin.jti) {
        return true;
    }
    else {
        return false;
    }



}

async function profileSetup(req, res) {


    const admin = await model.admin.findOneAndUpdate({ "_id": req.body.admin._id }, {
        $set: {
            firstname: req.body.firstname,
            lastname: req.body.lastname,
            email: req.body.email,
            gender: req.body.gender,
            age: req.body.age,
            type: req.body.type,
            password: await bcrypt.hash(req.body.password, 10)
        }
    }, { new: true });
    await admin.save();
    return admin;
}
async function login(req, res) {
    console.log(req.body.password);
    const admin = await model.admin.findOne({ phone: req.body.phone });
    // console.log(admin, " lllllllllllllllllllll")
    if (!admin) {
        return ("User not found");
    }
    else {
        let check = false;
        check = await bcrypt.compareSync(req.body.password, admin.password);
        console.log(check);
        //  check = true;
        if (check) {

            const token = await admin.generateToken();

            console.log({ "Token :: ": token })
            return { "Token :: ": token };

        }
        else {
            return ("Incorrect Password");
        }

    }
}

async function updateProfile(req, res, next) {
    const a1 = await model.admin.findOne({ "_id": req.body.admin._id });
    a1.firstname = req.body.firstname;
    a1.lastname = req.body.lastname;
    a1.email = req.body.email;
    a1.gender = req.body.gender
    a1.phone = req.body.phone
    a1.age = req.body.age;
    await a1.save();
    return a1;
}
async function sendOtpForForgotPassword(req, res, next) {
    const OTP = otpGenetaror.generate(6, { digits: true, lowerCaseAlphabets: false, upperCaseAlphabets: false, specialChars: false });
    const number = req.body.phone;
    const otp = new model.otp({
        phone: number,
        otpString: OTP
    });
    const result = await otp.save();
    return "OTP sent sucessfully";
}
async function setForgotPassword(req, res, next) {


    const admin = await model.admin.findOneAndUpdate({ "_id": req.body.admin._id }, {
        $set: {
            password: await bcrypt.hash(req.body.password, 10)
        }
    }, { new: true });
    await admin.save();
    return admin;
}
async function getProfile(req, res, next) {


    const a1 = await model.admin.findOne({ "_id": req.body.admin._id });
    if (!a1) {
        return "Admin not found"
    }
    //  console.log(u1.tokens[u1.tokens.length-1].token);

    console.log(a1.jti, '===', req.body.admin.jti);
    if (a1.jti === req.body.admin.jti) {
        return {
            "firstname": a1.firstname,
            "lastname": a1.lastname,
            "email": a1.email,
            "gender": a1.gender,
            "phone": a1.phone,
            "age": a1.age
        };
    }
    else { return "not found" }
}
async function changePassword(req, res, next) {
    const a1 = await model.admin.findOne({ "_id": req.body.admin._id });
    console.log(a1);

    console.log(a1.password, ' === ', req.body.oldPassword);
    let check = false;
    check = await bcrypt.compareSync(req.body.oldPassword, a1.password);
    if (check) {
        const admin = await model.admin.findOneAndUpdate({ "_id": req.body.admin._id }, {
            $set: {
                password: await bcrypt.hash(req.body.newpassword, 10)
            }
        }, { new: true });
        await admin.save();
        return admin;
    }
    else
        return "wrong Password";

}
module.exports = {
    sendOtp,
    verifyOtp,
    profileSetup,
    login,
    verifyToken,
    verifyAdmin,
    updateProfile,
    setForgotPassword,
    sendOtpForForgotPassword,
    verifyOtpForForgotPassword,
    getProfile,
    changePassword
}
module.exports = {
    admin: require("./admin"),
    student: require("./student")
}
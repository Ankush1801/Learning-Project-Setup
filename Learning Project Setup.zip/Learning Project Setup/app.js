const express = require("express");
const app = express();
const v1Routes = require("./v1/routes/index.js");
const connection = require("./connection/connection");
require("dotenv").config()
app.use(express.json())
app.use("/v1", v1Routes)
app.listen(process.env.PORT, async (req, res) => {
    console.log(`Server is running at ${process.env.PORT}`);
    await connection.connection();

})
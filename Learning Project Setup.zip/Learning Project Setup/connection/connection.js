const mongoose = require("mongoose");
let connection = () => {
    mongoose.connect("mongodb://localhost:27017/Learning_Project").then(function (abc) {
        console.log("Connection created")
    }).catch(function (err) {
        console.log(err);
    })

}
module.exports = {
    connection
};
const services = require("../../services/index.js");
const express = require("express");
const router = express.Router();

async function sendOtp(req, res) {
    try {

        const result = await services.admin.sendOtp(req, res)
        res.send(result);
    }
    catch (err) {
        console.log("Something went wrong!!");

    }
}
async function verifyOtp(req, res) {
    try {
        const result = await services.admin.verifyOtp(req, res)
        res.status(200).send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function verifyOtpForForgotPassword(req, res) {
    try {
        const result = await services.admin.verifyOtpForForgotPassword(req, res)
        res.status(200).send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function verifyToken(req, res, next) {
    try {
        await services.admin.verifyToken(req, res, next)

    }
    catch (err) {
        if (err)
            console.log(err);
        res.send("Invalid Token")


    }
}
async function profileSetup(req, res) {
    try {
        const result = await services.admin.profileSetup(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function login(req, res) {
    try {
        const result = await services.admin.login(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function verifyAdmin(req, res, next) {
    try {
        const result = await services.admin.verifyAdmin(req, res)
        console.log(result, " ********  ->  -> result");
        if (result) {
            console.log("Valid Token");
            next();
        }
        else {
            res.send("Token expired");
        }
    }
    catch (err) {
        console.log(err);

    }
}
async function updateProfile(req, res) {
    try {
        const result = await services.admin.updateProfile(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function sendOtpForForgotPassword(req, res) {
    try {
        const result = await services.admin.sendOtpForForgotPassword(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}

async function setForgotPassword(req, res) {
    try {
        const result = await services.admin.setForgotPassword(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function getProfile(req, res, next) {
    try {
        const result = await services.admin.getProfile(req, res, next);
        res.send(result);

    }
    catch (err) {
        if (err)
            console.log(err);
        res.send("Invalid Token")


    }
}
async function changePassword(req, res, next) {
    try {
        const result = await services.admin.changePassword(req, res, next);
        res.send(result);

    }
    catch (err) {
        if (err)
            console.log(err);
        res.send("Invalid Token")


    }
}
module.exports = {
    sendOtp,
    verifyOtp,
    profileSetup,
    login,
    verifyToken,
    updateProfile,
    verifyAdmin,
    setForgotPassword,
    sendOtpForForgotPassword,
    verifyOtpForForgotPassword,
    getProfile,
    changePassword

}
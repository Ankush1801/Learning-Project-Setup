module.exports = {

    adminController: require("./admin"),
    studentController:require("./student")
}
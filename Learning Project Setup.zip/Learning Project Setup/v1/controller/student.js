const services = require("../../services/index.js");
async function sendOtp(req, res) {
    try {

        const result = await services.student.sendOtp(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function verifyToken(req, res,next) {
    try {
        await services.student.verifyToken(req, res,next)
        
    }
    catch (err) {
        if(err)
        console.log(err);
        res.send("Invalid Token")
        

    }
}
async function verifyOtp(req, res) {
    try {
        const result = await services.student.verifyOtp(req, res)
        res.status(200).send(result);
    }
    catch (err) {
        console.log(err);

    }
}

async function profileSetup(req, res) {
    try {
        const result = await services.student.profileSetup(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
async function login(req, res) {
    try {
        const result = await services.student.login(req, res)
        res.send(result);
    }
    catch (err) {
        console.log(err);

    }
}
module.exports = {
    sendOtp,
    verifyOtp,
    profileSetup,
    login,
    verifyToken

}
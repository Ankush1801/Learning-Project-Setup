const express = require("express");
const router = express.Router();
const controller = require("../controller/index.js");
router.post("/sendOtp", controller.studentController.sendOtp);
router.get("/verifyOtp", controller.studentController.verifyOtp);
router.post("/profileSetup", controller.studentController.verifyToken,controller.studentController.profileSetup);
router.post("/login", controller.studentController.login);

module.exports = router;